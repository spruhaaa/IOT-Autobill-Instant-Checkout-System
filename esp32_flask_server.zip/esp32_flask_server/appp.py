# app.py
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload():
    image_file = request.files.get('image')
    if image_file:
        image_file.save(f"./received_images/{image_file.filename}")
        return jsonify({"message": "Image received successfully!"})
    return jsonify({"error": "No image received"}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
